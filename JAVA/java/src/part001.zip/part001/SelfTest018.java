package part001;

public class SelfTest018 {
	public static void cat() {
		System.out.println("야옹");
	}
	public static void main(String[] args) {
		cat();
	}
}
