package part001;

public class SelfTest010 {
	public static void main(String[] args) {
		int j=1;
		do { 
			System.out.print(j+" "); j++;
			} while (j<=10);
	}
}