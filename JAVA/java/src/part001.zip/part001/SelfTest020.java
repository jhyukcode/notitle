package part001;

public class SelfTest020 {
	public static String hi(String a) {
		return "Hi! "+a+"~!";
	}
	public static void main(String[] args) {
		System.out.println(hi("sally"));
	}
}
