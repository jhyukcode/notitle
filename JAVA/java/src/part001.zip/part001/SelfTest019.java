package part001;

public class SelfTest019 {
	public static void hap(int a, int b) {
		System.out.println("두 수의 합 : "+(a+b));
	}
	public static void main(String[] args) {
		hap(3,5);
	}
}
