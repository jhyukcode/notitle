package part001;

public class SelfTest001 {
	public static void main(String[] args) {
		System.out.println("Hello");
	}
}
