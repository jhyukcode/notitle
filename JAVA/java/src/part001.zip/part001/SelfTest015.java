package part001;

public class SelfTest015 {
	public static void main(String[] args) {
		
		int[] arr = new int[5];
		
		for(int i=0;i<5;i++) {
			arr[i] = i+1;
			System.out.print(arr[i]+" ");
		}
		
	}
}
