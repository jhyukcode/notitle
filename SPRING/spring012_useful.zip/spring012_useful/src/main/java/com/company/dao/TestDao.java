package com.company.dao;

@MyDao
public interface TestDao {
	public String readTime();
}
