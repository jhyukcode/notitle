package com.company.dao;

public @interface MyDao {

}
